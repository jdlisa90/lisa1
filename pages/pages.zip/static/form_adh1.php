<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/><meta charset="utf-8"/>
<title>Formulaire adhésion</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel='stylesheet' href='../../css/style2.css'/>
<link rel='stylesheet' href='../../css/style_articles2.css'/>
<script src="../../js/jquery-3.3.1.min.js"></script>
<script src="../../js/jquery.js"></script>
<script LANGUAGE='Javascript'>
<!--
$(function () {
	$("#submit").click(function () {
		valid=true;
		if($("#nom").val()==""){
			$("#nom").next(".error-message").fadeIn().text("Nom svp");
			valid=false;
		}
		else if(!$("#nom").val().match(/^[\w\-\sàáâãäåçèéêëìíîïðòóôõöùúûüýÿ]+$/i)){
			$("#nom").next(".error-message").fadeIn().text("Nom valide svp");
			valid=false;
		}		
		else {
			$("#nom").next(".error-message").fadeOut();
		}
		if($("#prenom").val()==""){
			$("#prenom").next(".error-message").fadeIn().text("Prénom svp");
			valid=false;
		}
		else if(!$("#prenom").val().match(/^[\w\-\sàáâãäåçèéêëìíîïðòóôõöùúûüýÿ]+$/i)){
			$("#prenom").next(".error-message").fadeIn().text("Prénom valide svp");
			valid=false;
		}		
		else {
			$("#prenom").next(".error-message").fadeOut();
		}
		if($("#adresse").val()==""){
			$("#adresse").next(".error-message").fadeIn().text("Adresse svp");
			valid=false;
		}
		else if($("#adresse").val().length<12){
			$("#adresse").next(".error-message").fadeIn().text("Adresse valide svp");
			valid=false;
		}		
		else {
			$("#adresse").next(".error-message").fadeOut();
		}		
		
		if($("#email").val()==""){
			$("#email").next(".error-message").fadeIn().text("Email svp");
			valid=false;
		}
		else if(!$("#email").val().match(/^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/)){
			$("#email").next(".error-message").fadeIn().text("Email valide svp");
			valid=false;
		}		
		else {
			$("#email").next(".error-message").fadeOut();
		}
		if($("#phone").val()==""){
			$("#phone").next(".error-message").fadeIn().text("Téléphone svp");
			valid=false;
		}
		else if($("#phone").val().match(/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/)){
			$("#phone").next(".error-message").fadeIn().text("Téléphone valide svp");
			valid=false;
		}		
		else {
			$("#phone").next(".error-message").fadeOut();
		}
		if($("input:checked").length==0){
			$("#error-activ").fadeIn().text("Veuillez choisir au moins une activité");
			valid=false;
		}
		else {
			$("#error-activ").fadeOut();
			
			if ($("#checkbox1").is(":checked") & $("#textfield1").val().length<5) {
				valid=false;
				$("#textfield1").next(".error-message").fadeIn().text("Veuillez compléter ce champ");

			}
			else {
				$("#textfield1").next(".error-message").fadeOut();
			}
			
			if ($("#checkbox3").is(":checked") & $("#textfield3").val().length<5) {
				valid=false;
				$("#textfield3").next(".error-message").fadeIn().text("Veuillez compléter ce champ");
			}
			else {
				$("#textfield3").next(".error-message").fadeOut();
			}
			
			if ($("#checkbox4").is(":checked") & $("#textfield4").val().length<5) {
				valid=false;
				$("#textfield4").next(".error-message").fadeIn().text("Veuillez compléter ce champ");
			}
			else {
				$("#textfield4").next(".error-message").fadeOut();
			}
		}
		return valid;
	});
});

//-->
</script>
<style type="text/css">
.error-message{
	background:url(../img/error.png) 1px center no-repeat;
	padding: 0 0 0 30px;
	display: inline;
	color: #ff5b5b;
	display: none;
}

</style>
</head>
<body bgcolor="#E8ECC8">
<div align='center'><table width="75%" border="0">
  <tr>
    <td>
      <h4 class="tit1">Demande d'adh&eacute;sion &agrave; l'association LISA90</h4>
      <form method="post" action="form_adh0.php">
<?php
$champs_id=array(
				"</td><td><td width='75%'>M.<input type='radio' name='sex' value='m'>&nbsp;&nbsp; Mme<input type='radio' name='sex' value='f'>",
				"Nom</td><td>*<td width='75%'><input type='text' name='nom' id='nom' size='40'>",
				"Pr&eacute;nom</td><td>*<td width='75%'> <input type='text' name='prenom' id='prenom' size='40'>",
				"Adresse compl&egrave;te</td><td>*<td width='75%'> <textarea name='adresse' id='adresse' cols='40'></textarea>",
				"Profession</td><td><td width='75%'> <input type='text' name='profession' size='40'>",
				"T&eacute;l&eacute;phone</td><td>*<td width='75%'> <input type='text' name='telephone' id='phone' size='40'>",
				"Email</td><td>*<td width='75%'> <input type='text' name='email' id='email' size='40'>",
				"Site web</td><td><td width='75%'><input type='text' name='site' size='40'>"
				);
$champs_act=array(
		"<input type='checkbox' name='checkbox1' id='checkbox1' value='y'>
            </td>
            <td width='95%'><b>D&eacute;pouillements</b>, sur l'interface en ligne exclusivement 
				<br>Secteur, époque ou archives de pr&eacute;dilection 
            <input type='text' name='textfield1' id='textfield1' size='50'><span class='error-message'>erreur</span>",

			  "<input type='checkbox' name='checkbox2' value='y'>
            </td>
            <td width='95%'><b>Num&eacute;risation</b> d'archives aux AD 90 (la possession 
              d'un appareil photo num&eacute;rique n'est pas nécessaire)",

			  "<input type='checkbox' name='checkbox3' id='checkbox3' value='y'>
            </td>
            <td width='95%'><b>R&eacute;alisation</b> de synth&egrave;ses historiques 
              ou familiales (ne se limitant pas &agrave; la fourniture de donn&eacute;es g&eacute;n&eacute;alogiques) en vue de leur publication sur le site de LISA. 
              A l'&eacute;tranger, &eacute;tude de l'&eacute;migration originaire du secteur de Belfort.<br>
              Pr&eacute;ciser le projet : 
              <input type='text' name='textfield3' id='textfield3' size='80'><span class='error-message'>erreur</span>",

			  "<input type='checkbox' name='checkbox4' id='checkbox4' value='y'>
            </td>
            <td width='95%'><b>Autre<br></b>
              Pr&eacute;ciser le projet : 
              <input type='text' name='textfield4' id='textfield4' size='80'><span class='error-message'>erreur</span>",
);

echo"<form method='post' action='verif_adh1.php'>";
echo"<i>Aucun des renseignements ci-dessous n'est directement recueilli par LISA ; ils sont 
		uniquement destinés à éditer votre demande d'adhésion.</i>";
echo"<h4><font size='-1'>Identit&eacute;</font> </h4>
<table border='0' width='100%'>";
foreach($champs_id as $ligne)	echo"<tr><td >".$ligne."<span class='error-message'>erreur</span>";
echo"</table>";
echo"<h4><font size='-1'>Activit&eacute; envisag&eacute;e au sein de LISA</font></h4>
<p>(une case au moins, dans la liste ci-dessous, doit &ecirc;tre coch&eacute;e)</p>
<table width='75%' border='0'>";
foreach($champs_act as $ligne)	echo"<tr><td valign='top'>".$ligne;
echo"</table><div class='error-message' id='error-activ'>erreur</div>";
echo"<h4><font size='-1'>Observations</font></h4>
			<table width='75%' border='0'><tr><td>
			<textarea name='divers' cols='72'></textarea>";
echo"<tr> 
    <td width='5%' valign='top'>&nbsp;</td>
    <td width='95%'> 
      <div align='right'><input type='image' name='submit' id='submit' src='..\..\img\go1.gif'></div>
    </td>
  </tr>
</table>".$obs;

/*

if($checkbox1)echo "<br><font size='2'>D&eacute;pouillements d'archives ; en particulier : ".$textfield1;
if($fr_lat=="fr") echo"<br>Je me limiterai aux originaux en français (ce qui exclut la plupart des registres paroissiaux).";
if($checkbox2)echo "<p><font size='2'>Je suis disposé à  réaliser des numérisations aux Archives Départementales de Belfort";
if($checkbox3)echo "<p><font size='2'>Je propose de r&eacute;aliser</b> des synth&egrave;ses historiques 
              ou familiales publiables sur le site de LISA. <br>
			  <i>Ces synthÃ¨ses se limiteront pas &agrave; la fourniture de donn&eacute;es g&eacute;n&eacute;alogiques.
			  </i><br>En particulier : ".$textfield3;
if($checkbox4)echo "<p><font size='2'>J'envisage de créer une section apparent&eacute;e ou 
              affili&eacute;e &agrave; Lisa dans une autre r&eacute;gion de l'hexagone.
			  <br>Plus précisément : ".$textfield4;
if($checkbox5)echo "<p><font size='2'>Je propose le projet suivant :</b>
			  <br>".$textfield5;
if($divers)ECHO "<p><p><font size='2'><b>Observations</b><br>".$divers;
ECHO "<br><br><br><p><p><font size='2'><i>Je certifie n'avoir aucune activité commerciale relative à  la généalogie.<br>
J'ai bien pris note du fait que mon adhésion devra être approuvée par le Conseil d'Administration de LISA et ne sera définitive
que lorsqu'un début de réalisation sera constaté par ce dernier.</i>";

if($checkbox1)echo "<br><br><p><i>Je m'engage à  ne transmettre à  quiconque, en tout ou en partie, aucun des documents qui me sont ou seront confiés par cette
association, et à  n'en réaliser aucune copie, même partielle.<br>";

ECHO "<br><br><font size='2'>
Le ".date("d/m/Y").".<p align='right'><i>Signature&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>	
<p>---------------------------------------------------
<P>A imprimer, signer et retourner &agrave; :<br>
  Association <B>LISA</B>, Archives d&eacute;partementales, 4 rue de l'Ancien 
  Th&eacute;&acirc;tre<br>
  90020 BELFORT Cedex</P>";
  
if($checkbox1)echo "<br><img src='../img/rect_n_dep.gif'><img src='../img/rect_n_dep.gif'> Vous envisagez de dépouiller des archives pour LISA ; cliquez 
<a href='Instructions_Lisa.html' target='_blank'>ici</a> pour prendre connaissance 
des consignes de dépouillement de l'état-civil.";
}*/
?>
      </form>
    </td>
  </tr>
</table>
</div></body>
</html>