<html>
<head>
<title>Formulaire adh�sion</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../css/ie5.css"></head>

<body bgcolor="#E8ECC8">
<div align='center'><table width="75%" border="0">
  <tr>
    <td>
      <h4 class="tit1">Demande d'adh&eacute;sion &agrave; l'association LISA90</h4>
<?php
extract($_POST,EXTR_OVERWRITE);
$bad=2;
$bad_id=2;
$bad_act=2;
$bad_field=2;

for ($e=1;$e<7;$e++){
	if ($e<>4 AND ${"field".$e}=="")	$bad_id=1;
}

for ($e=1;$e<6;$e++) $check.=${"checkbox".$e};
if ($check=="") $bad_act=1;

$fields=array("1","4","5");
foreach($fields as $e)	{
	if (${"checkbox".$e}<>"" AND ${"textfield".$e}=="") $bad_field=1;
}

if($bad_id==1 OR $bad_act==1 OR $bad_field==1) $bad=1;

include("../../include/form_adh.inc");
?>

    </td>
  </tr>
</table>
</div></body>
</html>