<?php
    $content="<div class='row justify-content-center pt-4'>
    <div class='col-7 form-vp'>
        <h3>Formulaire de contact</h3><br>
        <div class='row pt-3'>
            <div class='col-3'>
            Auteur
            </div>
            <div class='col-9'>
            <input type='text' name='auteur' id='auteur_contact'>
            </div>
        </div>
        <div class='row'>
            <div class='col-3'>
            E-mail*
            </div>
            <div class='col-9'>
            <input type='text' name='adresse' id='adresse_contact'><span class='error-message'></span>
            </div>
        </div>
        <div class='row'>
            <div class='col-3'>
            Titre
            </div>
            <div class='col-9'>
            <input type='text' name='titre' id='titre_contact'>
            </div>
        </div>
        <div class='row'>
            <div class='col-3'>
            Message*
            </div>
            <div class='col-9'>
            <textarea name='message' id='message_contact' rows='6'></textarea>
            <span style='' class='error-message' id='message_erreur'></span>
            </div>
        </div>
        <div class='row'>
            <div class='col-3'>
            Veuillez recopier le code*<br><img src='captcha.php' alt='CAPTCHA'>&nbsp;
            </div>
            <div class='col-9'>
            <input type='text' id='captcha' name='captcha' />
            </div>
        </div>
        <div class='row'>
            <div class='col-3'>
            </div>
            <div class='col-9'>
            <button type='button' class='btn btn-secondary' id='submit_contact'>Go</button>
            </div>
        </div>
    </div>
    <div class='col-1'>
        <img src='../img/first_logo.jpg' width='115' height='99' alt=''>
    </div>
</div>";
?>
<script>
$(function () {		//pour la page de contact
	$("#submit_contact").click(function () {
		valid=true;
		if($("#adresse_contact").val()==""){
			$("#adresse_contact").next(".error-message").fadeIn().text("Email svp");
			valid=false;
		}
		else if(!$("#adresse_contact").val().match(/^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/)){
			$("#adresse_contact").next(".error-message").fadeIn().text("Email valide svp");
			valid=false;
		}		
		else {
			$("#adresse_contact").next(".error-message").fadeOut();
		}

		if ($("#message_contact").val().length<5) {
			valid=false;
			$("#message_erreur").fadeIn().text("Veuillez compléter le champ message");
		}
		else {
			$("#message_erreur").fadeOut();
		}
		if(valid==true){
			$(function () {
				var fd = new FormData();
				fd.append('auteur',$("#auteur_contact").val());
				fd.append('email',$("#adresse_contact").val());
				fd.append('titre',$("#titre_contact").val());
				fd.append('message',$("#message_contact").val());
				fd.append('captcha',$("#captcha").val());
				//alert($("#message_contact").val()+" "+$("#adresse_contact").val()+" "+$("#captcha").val());
				$.ajax({		// instancie implicitement un objet XmlHttpRequest
                    url:'ajax_contact_valid.php',		// La ressource ciblée:
                    type:'post',
                    data:fd,					// l'objet FormData
                    dataType:'json',
                    contentType: false,	// pour empêcher jQuery d'ajouter un header
                    processData: false,	// (boolean) pour empêcher jQuery de convertir l'objet FormData en string
                    success:function(response){		// callback function à exécuter when Ajax request succeeds ; response est la donnée retournée par la page url
                        if(response != ""){
                                //alert(response.res);
                            if(response.res==1){		// l'élément $(this) n'est plus disponible à cet endroit
                                //alert(response.res);
                                alert(response.result);
                            }
                            else{
                                alert(response.result);
                            }
                        }
                        else{
                            alert('Nada');
                        }
                    }		// fin de success
	            });		// fin de $.ajax
			});
		}
		return false;
	});
	$("#refresh_cap").click(function(){
    	alert("do");
		$("#captcha").attr("src","captcha.php");
    });
});
</script>