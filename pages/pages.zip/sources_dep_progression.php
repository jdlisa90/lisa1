<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script LANGUAGE="Javascript">
google.charts.load('current', {'packages':['corechart']});
$(document).ready(function () {
	console.log("document is ready");
	var fd = new FormData();
	var tab;
	$.ajax({
        url:'chart_actes.php',
        type:'post',
        data:fd,
        dataType:'json',
        contentType: false,
        processData: false,
        success:function(response){
            if(response != ""){
                var monTableau = Object.keys(response).map(function(cle) {
                        return [cle, response[cle]];
                });
                console.log(monTableau);
                var data = google.visualization.arrayToDataTable(monTableau);
                var options = {
                    fontSize: 10,
                    chartArea:{left:60,top:30,width:'90%',height:'75%'},
                    colors: ['#cccc99'],
                    backgroundColor: "#e8ecc8",
                    legend: {position: 'bottom'},
                    lineWidth: 3,
                    vAxis: {format: 'decimal'},
                    hAxis: {slantedTextAngle: -45}
                };
                var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
                chart.draw(data, options);
            }
            else{
                alert('Nada');
            }
        }		// fin de success
    });		// fin de $.ajax
});
</script>

<?php
$content="<div class='row justify-content-center'>
<div class='col ps-0 pt-3'>
<h4>Progression des dépouillements</h4>"; // row contenant et colonne principale
$content.="<div id='curve_chart' style='width: 1000px; height: 500px'></div>
<p>Le graphique (dynamique) ci-dessus représente le cumul des actes dépouillés depuis la mise en œuvre de notre <b>interface de saisie en ligne</b>.
<br><br>Il affiche une croissance régulière, les quelques sauts (début 2019 ou avril 2020) correspondant à des mises en ligne en bloc d'anciens 
dépouillements réalisés sur des supports externes.
<br><br><b>Merci à nos courageux bénévoles</b>.";

$content.="</div>"; // fermeture row contenant
?>