<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/><meta charset="utf-8"/>
<title>Formulaire adhésion</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href='http://fonts.googleapis.com/css?family=Kreon:400,300,700' rel='stylesheet' type='text/css'>
<link rel='stylesheet' href='../../css/style2.css'/>
<link rel='stylesheet' href='../../css/style_articles2.css'/>
</head>

<body>
<div align='center'><table width="75%" border="0">
  <tr>
    <td>
      <div class="titre2">Demande d'adh&eacute;sion &agrave; l'association LISA90<br></div><br>
<?php
extract($_POST);
if ($sex=='m') $st="M. ";
if ($sex=='f') $st="Mme ou Mlle ";
$st.="<strong>".$prenom." ".strtoupper($nom)."</strong><br>".$adresse;
if($profession) $st.="<p>Profession : ".$profession;
$st.="<p>Tel : ".$telephone."<br>Email : ".$email;
if($site) $st.="<br>Site Web : ".$site;

echo $st."<p><br><div class='titre3'>Activité(s) envisagée(s) dans l'association :</div><ul>";

if($checkbox1)echo "<li><strong>D&eacute;pouillements d'archives</strong> ; <strong><em>en particulier</em></strong> : ".$textfield1."</li>";
if($checkbox2)echo "<li>Je suis disposé à  réaliser des <strong>numérisations</strong> aux Archives Départementales de Belfort</li>";
if($checkbox3)echo "<li>Je propose de r&eacute;aliser</b> des <strong>synth&egrave;ses historiques</strong> 
              ou familiales publiables sur le site de LISA. <br>
			  <i>Ces synthèses se limiteront pas &agrave; la fourniture de donn&eacute;es g&eacute;n&eacute;alogiques.
			  <br><strong>En particulier</strong></i> : ".$textfield3."</li>";
if($checkbox4)echo "<li>Je propose <strong>le projet suivant</strong> :</b>
			  <br>".$textfield4."</li>";
echo"</ul>";
if($divers)ECHO "<p><p><b>Observations :</b><br>".$divers;
ECHO "<p><br><i>Je certifie n'avoir aucune activité commerciale relative à  la généalogie.<br>
J'ai bien pris note que mon adhésion devra être approuvée par le Conseil d'Administration de LISA et ne sera définitive
que lorsqu'un début de réalisation sera constaté par ce dernier.</i>";

if($checkbox1)echo "<br><p><i>Je m'engage à ne transmettre à quiconque, en tout ou en partie, aucun des documents qui me sont ou seront confiés par cette
association, et à n'en réaliser aucune copie, même partielle.</i><br>";

ECHO "<br><br>
Le ".date("d/m/Y").".<p align='right'><i>Signature&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>	
<p>---------------------------------------------------
<P>A imprimer, signer et expédier &agrave; :<br>
  Association <B>LISA</B>, Archives d&eacute;partementales, 4 rue de l'Ancien 
  Th&eacute;&acirc;tre<br>
  90020 BELFORT Cedex</P>";
?>
    </td>
  </tr>
</table>
</div></body>
</html>