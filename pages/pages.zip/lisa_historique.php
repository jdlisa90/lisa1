<?php
/* session_start();
try {$bdd = new PDO('mysql:host=localhost;dbname=lisa90;charset=utf8', 'lisa90', 'jlpmjg90',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ));}
catch(Exception $e) {exit(json_encode(array("result"=>'<b>Exception at line '.$e->getLine() .' :</b> '. $e->getMessage(),"res"=>0)));} */
// ne sont pas nécessaires dans un include (le seraient dans une requête ajax)
function dat($dat,$l){
	$pieces=explode("-",$dat);
	return date("d/m/y",mktime(0,0,0,$pieces[1],$pieces[2],$pieces[0]));
}
$titre="Historique des mises à jour";
$sect=array(0=>"Structure du site",1=>"Ajout d'une archive dans la base de données", 2=>"Nouveaux articles", 3=>"Prénoms anciens", 4=>"Histoire",	6=>"Recensement", 9=>"Administration");
$content= "<div class='col mt-3'><h3>Historique des mises à jour</h3><br>";
$sql="SELECT *,UNIX_TIMESTAMP(date_maj) AS u FROM histo ORDER BY date_maj DESC";
try {$id=$bdd->query($sql);}
catch(Exception $e) {exit('<b>Exception at line '. $e->getLine() .' :</b> '. $e->getMessage());}
while($l=$id->fetch(PDO::FETCH_ASSOC)){
	$content.="<div class='row pb-2 pt-2'>";
    if ($l["sect"]==1 and $l["lien"]>0){
        if($l["u"]<mktime(0,0,0,1,18,2007)) $sql1="SELECT type_arch,lib FROM arch_ssserie WHERE id1=".$l["lien"];
		else $sql1="SELECT type_arch,lib FROM arch_ssserie WHERE id=".$l["lien"];
		try {$id1=$bdd->query($sql1);}
		catch(Exception $e) {exit('<b>Exception at line '. $e->getLine() .' :</b> '. $e->getMessage());}
		$l1=$id1->fetch(PDO::FETCH_ASSOC);
		$lib="<b>"."(".$type_arch[$l1["type_arch"]].") ".$l1["lib"]."</b>";
    }
	else $lib="";
	$content.="<div class='col-2'>".dat($l["date_maj"],$lang)."</div><div class='col-10'>";
	if($l["sect"]!=1) $content.="<i>".$sect[$l["sect"]]."</i><br>";
	$content.=$lib;
	if($l["comment_aff"]!="") $content.= "<br>".trim($l["comment_aff"]);
	else if($l["sect"]!=1 AND $l["comment"]<>"") $content.= trim(nl2br($l["comment"]));
	$content.="</div></div>";
}
$content.="</div>";
?>