
<?php
/* session_start();
try {$bdd = new PDO('mysql:host=localhost;dbname=lisa90;charset=utf8', 'lisa90', 'jlpmjg90',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ));}
catch(Exception $e) {exit(json_encode(array('result'=>'<b>Exception at line '.$e->getLine() .' :</b> '. $e->getMessage(),'res'=>0)));} */
// ne sont pas nécessaires dans un include (le seraient dans une requête ajax)

// l'élément parent est : <div class='col ps-0 ms-0' id='content' style='min-height:80vh;'>, qui applique une bordure fine en bas de ses enfants directs 'row' ou 'col'

$content="<div class='row justify-content-center'>
<div class='col pt-4 pb-4 flex-grow-0'>"; // colonne centrée
$content.="<h4>COMMUNES du Territoire-de-Belfort</h4>
<img src='../img/cartes/tdb2.png' alt='' usemap='#communes-map'>
<map name='communes-map'>
    <area target='' alt='Croix' title='Croix' href='accueil1-entites_commune-ent-30.html' coords='484,1115,426,1076' shape='rect'>
    <area target='' alt='Villars-le-Sec' title='Villars' href='accueil1-entites_commune-ent-108.html' coords='556,1047,505,1077' shape='rect'>
    <area target='' alt='Saint-Dizier' title='Saint-Dizier' href='accueil1-entites_commune-ent-93.html' coords='437,999,500,1060' shape='rect'>
    <area target='' alt='Montbouton' title='Montbouton' href='accueil1-entites_commune-ent-71.html' coords='422,1013,369,1050' shape='rect'>
    <area target='' alt='Beaucourt' title='Beaucourt' href='accueil1-entites_commune-ent-9.html' coords='425,949,367,995' shape='rect'>
    <area target='' alt='Lebetain' title='Lebetain' href='accueil1-entites_commune-ent-64.html' coords='522,949,471,991' shape='rect'>
    <area target='' alt='Fêche-l'Église' title='Fêche-l'Église' href='accueil1-entites_commune-ent-45.html' coords='476,896,430,947' shape='rect'>
    <area target='' alt='Delle' title='Delle' href='accueil1-entites_commune-ent-33.html' coords='588,889,500,934' shape='rect'>
    <area target='' alt='Thiancourt' title='Thiancourt' href='accueil1-entites_commune-ent-99.html' coords='532,860,486,897,467,885,520,850' shape='poly'>
    <area target='' alt='Joncherey' title='Joncherey' href='accueil1-entites_commune-ent-57.html' coords='585,809,577,859,545,856,529,833,558,808' shape='poly'>
    <area target='' alt='Courcelles' title='Courcelles' href='accueil1-entites_commune-ent-27.html' coords='726,905,722,931,694,945,631,927,688,906' shape='poly'>
    <area target='' alt='Rechésy' title='Rechésy' href='accueil1-entites_commune-ent-83.html' coords='799,815,801,895,748,921,732,889,743,837' shape='poly'>
    <area target='' alt='Florimont' title='Florimont' href='accueil1-entites_commune-ent-47.html' coords='679,816,681,890,623,915,606,897,656,859,647,816,602,745,607,712' shape='poly'>
    <area target='' alt='Courtelevant' title='Courtelevant' href='accueil1-entites_commune-ent-28.html' coords='736,825,718,888,691,876,696,817' shape='poly'>
    <area target='' alt='Faverois' title='Faverois' href='accueil1-entites_commune-ent-44.html' coords='631,805,632,862,604,880,592,870,595,813' shape='poly'>
    <area target='' alt='Lepuix-Neuf' title='Lepuix-Neuf' href='accueil1-entites_commune-ent-66.html' coords='791,802,743,817,712,805,707,791,738,779' shape='poly'>
    <area target='' alt='Grandvillars' title='Grandvillars' href='accueil1-entites_commune-ent-54.html' coords='540,805,504,835,501,854,443,874,440,834,462,779,508,769' shape='poly'>
    <area target='' alt='Meziré' title='Meziré' href='accueil1-entites_commune-ent-70.html' coords='406,872,406,847,382,811,368,816,371,863' shape='poly'>
    <area target='' alt='Suarce' title='Suarce' href='accueil1-entites_commune-ent-98.html' coords='740,756,677,793,646,738,702,695' shape='poly'>
    <area target='' alt='Boron' title='Boron' href='accueil1-entites_commune-ent-14.html' coords='609,791,539,791,527,770,550,745,574,752' shape='poly'>
    <area target='' alt='Chavanatte' title='Chavanatte' href='accueil1-entites_commune-ent-24.html' coords='694,685,651,716,651,693,668,665,694,663' shape='poly'>
    <area target='' alt='Morvillars' title='Morvillars' href='accueil1-entites_commune-ent-74.html' coords='445,779,421,855,407,825,393,801,407,778' shape='poly'>
    <area target='' alt='Chavannes-les-Grands' title='Chavannes-les-Grands' href='accueil1-entites_commune-ent-25.html' coords='666,647,643,692,593,685,583,666,613,636,635,644' shape='poly'>
    <area target='' alt='Vellescot' title='Vellescot' href='accueil1-entites_commune-ent-104.html' coords='592,699,580,737,549,731,551,691,571,687' shape='poly'>
    <area target='' alt='Grosne' title='Grosne' href='accueil1-entites_commune-ent-56.html' coords='543,698,533,743,510,750,513,702' shape='poly'>
    <area target='' alt='Froidefontaine' title='Froidefontaine' href='accueil1-entites_commune-ent-52.html' coords='492,756,447,767,414,766,414,753,441,728' shape='poly'>
    <area target='' alt='Recouvrance' title='Recouvrance' href='accueil1-entites_commune-ent-85.html' coords='506,708,492,748,476,741,489,712' shape='poly'>
    <area target='' alt='Bourogne' title='Bourogne' href='accueil1-entites_commune-ent-17.html' coords='406,742,365,806,325,788,302,750,320,713,361,707' shape='poly'>
    <area target='' alt='Brebotte' title='Brebotte' href='accueil1-entites_commune-ent-18.html' coords='514,690,486,705,471,738,450,721,477,682' shape='poly'>
    <area target='' alt='Bretagne' title='Bretagne' href='accueil1-entites_commune-ent-19.html' coords='567,650,559,684,528,685,496,664,526,642' shape='poly'>
    <area target='' alt='Rechotte' title='Rechotte' href='accueil1-entites_commune-ent-84.html' coords='464,648,460,662,445,663,438,647,454,644' shape='poly'>
    <area target='' alt='Montreux-Château' title='Montreux-Château' href='accueil1-entites_commune-ent-72.html' coords='539,631,496,650,493,627,507,583,535,587' shape='poly'>
    <area target='' alt='Novillard' title='Novillard' href='accueil1-entites_commune-ent-76.html' coords='484,643,448,637,426,632,435,615,460,605,478,624' shape='poly'>
    <area target='' alt='Charmois' title='Charmois' href='accueil1-entites_commune-ent-21.html' coords='443,692,422,736,388,713,422,676' shape='poly'>
    <area target='' alt='Eschêne-Autrage' title='Eschêne-Autrage' href='accueil1-entites_commune-ent-38.html' coords='487,655,474,677,454,694,448,670,475,654' shape='poly'>
    <area target='' alt='Petit-Croix' title='Petit-Croix' href='accueil1-entites_commune-ent-79.html' coords='496,592,489,616,465,598,459,542' shape='poly'>
    <area target='' alt='Fontenelle' title='Fontenelle' href='accueil1-entites_commune-ent-49.html' coords='455,567,455,596,435,607,424,584,432,570' shape='poly'>
    <area target='' alt='Meroux' title='Meroux' href='accueil1-entites_commune-ent-69.html' coords='422,669,382,701,356,693,330,700,307,673,316,639' shape='poly'>
    <area target='' alt='Vézelois' title='Vézelois' href='accueil1-entites_commune-ent-107.html' coords='425,610,412,658,334,631,317,615,315,591' shape='poly'>
    <area target='' alt='Cunelières' title='Cunelières' href='accueil1-entites_commune-ent-31.html' coords='534,579,498,575,489,564,502,556,530,554,542,566' shape='poly'>
    <area target='' alt='Foussemagne' title='Foussemagne' href='accueil1-entites_commune-ent-50.html' coords='554,515,544,550,523,546,480,556,478,541,512,523,515,496' shape='poly'>
    <area target='' alt='Frais' title='Frais' href='accueil1-entites_commune-ent-51.html' coords='507,496,506,519,475,530,468,491,487,488' shape='poly'>
    <area target='' alt='Bessoncourt' title='Bessoncourt' href='accueil1-entites_commune-ent-12.html' coords='459,491,464,530,356,535,378,490' shape='poly'>
    <area target='' alt='Chèvremont' title='Chèvremont' href='accueil1-entites_commune-ent-26.html' coords='446,558,418,569,417,594,326,585,357,543,440,539' shape='poly'>
    <area target='' alt='Vourvenans' title='Vourvenans' href='accueil1-entites_commune-ent-109.html' coords='302,782,263,801,267,768,291,757,304,765' shape='poly'>
    <area target='' alt='Moval' title='Moval' href='accueil1-entites_commune-ent-75.html' coords='324,700,303,705,295,681,312,683' shape='poly'>
    <area target='' alt='Trétudans' title='Trétudans' href='accueil1-entites_commune-ent-100.html' coords='305,710,289,748,260,757,264,710' shape='poly'>
    <area target='' alt='Sévenans' title='Sévenans' href='accueil1-entites_commune-ent-97.html' coords='297,674,286,676,289,694,263,705,261,679,277,667,299,658' shape='poly'>
    <area target='' alt='Châtenois-les-Forges' title='Châtenois-les-Forges' href='accueil1-entites_commune-ent-22.html' coords='242,746,255,772,253,800,184,808,161,761,185,739,210,755' shape='poly'>
    <area target='' alt='Bermont' title='Bermont' href='accueil1-entites_commune-ent-11.html' coords='255,704,252,745,197,742,234,711' shape='poly'>
    <area target='' alt='Dorans' title='Dorans' href='accueil1-entites_commune-ent-35.html' coords='250,696,221,709,209,728,190,730,204,667,224,686' shape='poly'>
    <area target='' alt='Andelnans' title='Andelnans' href='accueil1-entites_commune-ent-1.html' coords='305,651,264,667,243,648,219,642,220,634,289,627' shape='poly'>
    <area target='' alt='Botans' title='Botans' href='accueil1-entites_commune-ent-15.html' coords='258,669,253,682,222,678,213,659,219,652,242,652' shape='poly'>
    <area target='' alt='Perouse' title='Perouse' href='accueil1-entites_commune-ent-78.html' coords='348,529,318,581,286,565,310,520,327,509' shape='poly'>
    <area target='' alt='Danjoutin' title='Danjoutin' href='accueil1-entites_commune-ent-32.html' coords='307,587,298,616,228,623,233,603,288,573' shape='poly'>
    <area target='' alt='Banvillars' title='Banvillars' href='accueil1-entites_commune-ent-7.html' coords='199,665,179,721,123,670' shape='poly'>
    <area target='' alt='Argiésans' title='Argiésans' href='accueil1-entites_commune-ent-4.html' coords='213,642,206,658,152,657,172,637,171,617' shape='poly'>
    <area target='' alt='Urcerey' title='Urcerey' href='accueil1-entites_commune-ent-101.html' coords='163,609,165,638,129,654,120,644,140,615,139,593' shape='poly'>
    <area target='' alt='Bavilliers' title='Bavilliers' href='accueil1-entites_commune-ent-8.html' coords='226,596,213,628,154,593,187,586,204,562' shape='poly'>
    <area target='' alt='Belfort' title='Belfort' href='accueil1-entites_commune-ent-10.html' coords='301,527,275,570,234,589,191,525,213,520,210,487,171,498,131,506,119,494,146,475,189,461,225,487' shape='poly'>
    <area target='' alt='Buc' title='Buc' href='accueil1-entites_commune-ent-20.html' coords='131,595,126,627,115,638,91,623,98,577' shape='poly'>
    <area target='' alt='Essert' title='Essert' href='accueil1-entites_commune-ent-39.html' coords='197,552,180,581,122,583,121,521,148,520,185,530' shape='poly'>
    <area target='' alt='Cravanche' title='Cravanche' href='accueil1-entites_commune-ent-29.html' coords='205,496,202,514,165,521,147,507' shape='poly'>
    <area target='' alt='Denney' title='Denney' href='accueil1-entites_commune-ent-34.html' coords='374,484,348,514,328,506,306,508,328,467,362,474,369,476' shape='poly'>
    <area target='' alt='Évette-Salbert' title='Évette-Salbert' href='accueil1-entites_commune-ent-43.html' coords='179,448,122,481,116,509,71,459,87,407,120,408' shape='poly'>
    <area target='' alt='Phaffans' title='Phaffans' href='accueil1-entites_commune-ent-82.html' coords='447,489,424,463,386,466,382,488' shape='poly'>
    <area target='' alt='Fontaine' title='Fontaine' href='accueil1-entites_commune-ent-48.html' coords='563,463,552,500,511,489,470,481,470,449,534,445' shape='poly'>
    <area target='' alt='Lacollonge' title='Lacollonge' href='accueil1-entites_commune-ent-60.html' coords='465,447,466,477,447,482,416,454,444,448,455,445' shape='poly'>
    <area target='' alt='Reppe' title='Reppe' href='accueil1-entites_commune-ent-86.html' coords='609,423,599,488,565,491,566,450,556,441,577,430' shape='poly'>
    <area target='' alt='Vauthiermont' title='Vauthiermont' href='accueil1-entites_commune-ent-103.html' coords='609,398,553,434,535,420,534,391,590,373' shape='poly'>
    <area target='' alt='Larivière' title='Larivière' href='accueil1-entites_commune-ent-63.html' coords='542,433,472,442,476,424,495,416,507,391,519,390' shape='poly'>
    <area target='' alt='Lagrange' title='Lagrange' href='accueil1-entites_commune-ent-61.html' coords='494,394,485,416,474,418,453,384' shape='poly'>
    <area target='' alt='Angeot' title='Angeot' href='accueil1-entites_commune-ent-2.html' coords='586,367,535,385,469,382,518,344,566,337' shape='poly'>
    <area target='' alt='Bethonvilliers' title='Bethonvilliers' href='accueil1-entites_commune-ent-13.html' coords='470,418,462,432,446,426,438,393,452,389' shape='poly'>
    <area target='' alt='Menoncourt' title='Menoncourt' href='accueil1-entites_commune-ent-68.html' coords='450,440,403,449,400,423,407,383,431,387' shape='poly'>
    <area target='' alt='Eguenigue' title='Eguenigue' href='accueil1-entites_commune-ent-36.html' coords='402,378,396,453,380,457,374,387' shape='poly'>
    <area target='' alt='Sainf-Germain-le-Châtelet' title='Sainf-Germain-le-Châtelet' href='accueil1-entites_commune-ent-94.html' coords='472,371,434,385,424,367,431,332' shape='poly'>
    <area target='' alt='Felon' title='Felon' href='accueil1-entites_commune-ent-46.html' coords='511,337,473,362,436,322,486,308' shape='poly'>
    <area target='' alt='Lachapelle-sous-Rougemont' title='Lachapelle-sous-Rougemont' href='accueil1-entites_commune-ent-59.html' coords='577,278,568,330,517,332,502,312' shape='poly'>
    <area target='' alt='Petitefontaine' title='Petitefontaine' href='accueil1-entites_commune-ent-80.html' coords='569,274,499,308,489,296,552,254' shape='poly'>
    <area target='' alt='Leval' title='Leval' href='accueil1-entites_commune-ent-67.html' coords='548,248,481,297,453,277,506,222' shape='poly'>
    <area target='' alt='Rougemont-le-Château' title='Rougemont-le-Château' href='accueil1-entites_commune-ent-91.html' coords='496,223,448,273,406,286,364,222,377,162' shape='poly'>
    <area target='' alt='Romagny-sous-Rougemont' title='Romagny-sous-Rougemont' href='accueil1-entites_commune-ent-88.html' coords='478,304,433,315,437,283,451,282' shape='poly'>
    <area target='' alt='Bourg-sous-Châtelet' title='Bourg-sous-Châtelet' href='accueil1-entites_commune-ent-16.html' coords='429,299,421,363,399,353,415,296' shape='poly'>
    <area target='' alt='Anjoutey' title='Anjoutey' href='accueil1-entites_commune-ent-3.html' coords='408,371,358,381,308,377,307,367,365,352,396,301,405,302,394,354' shape='poly'>
    <area target='' alt='Étueffont' title='Étueffont' href='accueil1-entites_commune-ent-41.html' coords='396,290,354,342,314,354,313,333,342,311,346,232,374,250' shape='poly'>
    <area target='' alt='Roppe' title='Roppe' href='accueil1-entites_commune-ent-89.html' coords='370,394,376,465,350,463,337,439,303,418,311,390' shape='poly'>
    <area target='' alt='Vétrigne' title='Vétrigne' href='accueil1-entites_commune-ent-106.html' coords='340,458,317,477,299,452,303,426' shape='poly'>
    <area target='' alt='Offemont' title='Offemont' href='accueil1-entites_commune-ent-77.html' coords='310,489,290,500,240,482,261,435,288,445' shape='poly'>
    <area target='' alt='Éloie' title='Éloie' href='accueil1-entites_commune-ent-37.html' coords='302,383,290,434,240,417,252,368,281,373' shape='poly'>
    <area target='' alt='Petitmagny' title='Petitmagny' href='accueil1-entites_commune-ent-81.html' coords='335,238,333,307,312,314,308,251' shape='poly'>
    <area target='' alt='Valdoie' title='Valdoie' href='accueil1-entites_commune-ent-102.html' coords='249,437,238,476,208,469,196,441,231,421' shape='poly'>
    <area target='' alt='Grosmagny' title='Grosmagny' href='accueil1-entites_commune-ent-55.html' coords='301,248,299,365,264,354,249,321,255,295' shape='poly'>
    <area target='' alt='Sermamagny' title='Sermamagny' href='accueil1-entites_commune-ent-96.html' coords='245,375,227,417,183,441,135,406,185,377' shape='poly'>
    <area target='' alt='Chaux' title='Chaux' href='accueil1-entites_commune-ent-23.html' coords='257,357,191,367,141,305,182,287' shape='poly'>
    <area target='' alt='Lamadeleine' title='Lamadeleine' href='accueil1-entites_commune-ent-62.html' coords='356,158,351,220,297,216,320,140' shape='poly'>
    <area target='' alt='Rougegoutte' title='Rougegoutte' href='accueil1-entites_commune-ent-90.html' coords='288,218,277,264,221,321,194,275,231,258,258,224' shape='poly'>
    <area target='' alt='Lachapelle-sous-Chaux' title='Lachapelle-sous-Chaux' href='accueil1-entites_commune-ent-58.html' coords='183,373,90,400,73,339,138,313,156,334' shape='poly'>
    <area target='' alt='Auxelles-Bas' title='Auxelles-Bas' href='accueil1-entites_commune-ent-5.html' coords='142,288,67,335,41,268,96,267,126,259' shape='poly'>
    <area target='' alt='Riervescemont' title='Riervescemont' href='accueil1-entites_commune-ent-87.html' coords='308,142,291,200,241,200,227,154,245,125' shape='poly'>
    <area target='' alt='Vescemont' title='Vescemont' href='accueil1-entites_commune-ent-105.html' coords='257,215,211,261,196,264,194,206,200,169,220,171' shape='poly'>
    <area target='' alt='Giromagny' title='Giromagny' href='accueil1-entites_commune-ent-53.html' coords='185,208,191,269,153,289,130,240' shape='poly'>
    <area target='' alt='Auxelles-Haut' title='Auxelles-Haut' href='accueil1-entites_commune-ent-6.html' coords='125,254,46,260,42,235,71,183' shape='poly'>
    <area target='' alt='Lepuix' title='Lepuix' href='accueil1-entites_commune-ent-65.html' coords='229,126,136,231,75,172,179,23' shape='poly'>
</map>";
$content.="</div>
</div>"; // </ col et row>
?> 
